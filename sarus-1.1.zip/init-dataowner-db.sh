psql -v ON_ERROR_STOP=1 --username postgres --dbname postgres <<-EOSQL
    CREATE USER private_learning_lab WITH ENCRYPTED PASSWORD '${POSTGRES_PRIVATE_LEARNING_LAB_PASSWORD}';
    CREATE USER dataowner_api WITH ENCRYPTED PASSWORD '${POSTGRES_DATAOWNER_API_PASSWORD}';
    CREATE DATABASE dataowner;
EOSQL
psql -v ON_ERROR_STOP=1 --username postgres --dbname dataowner <<-EOSQL
    GRANT ALL PRIVILEGES ON DATABASE dataowner TO dataowner_api;
    GRANT CONNECT ON DATABASE dataowner TO private_learning_lab;
    ALTER DEFAULT PRIVILEGES GRANT SELECT ON TABLES TO private_learning_lab;
EOSQL
