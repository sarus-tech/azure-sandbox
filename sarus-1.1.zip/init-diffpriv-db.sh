psql -v ON_ERROR_STOP=1 --username postgres --dbname postgres <<-EOSQL
    CREATE USER private_learning_lab WITH ENCRYPTED PASSWORD '${POSTGRES_PRIVATE_LEARNING_LAB_PASSWORD}';
    CREATE USER dataowner_api WITH ENCRYPTED PASSWORD '${POSTGRES_DATAOWNER_API_PASSWORD}';
    CREATE DATABASE dataowner;
    \c dataowner;
    CREATE EXTENSION anon_func;
EOSQL
psql -v ON_ERROR_STOP=1 --username postgres --dbname dataowner <<-EOSQL
    GRANT ALL PRIVILEGES ON DATABASE dataowner TO dataowner_api;
    GRANT CONNECT ON DATABASE dataowner TO private_learning_lab;
    ALTER DEFAULT PRIVILEGES GRANT SELECT ON TABLES TO private_learning_lab;
EOSQL
# psql timeout, 5 min, see
# https://stackoverflow.com/questions/38142257/how-to-set-postgres-query-execution-timeout-from-application-level
psql -v ON_ERROR_STOP=1 --username postgres --dbname dataowner <<-EOSQL
    SET statement_timeout TO 300000;
EOSQL
