#/bin/bash

u_flag=''
p_flag=''

print_usage() {
  printf "Usage: installer.sh -u USERNAME -p PASSWORD"
}

while getopts ':u:p:' flag; do
  case "${flag}" in
    u) u_flag='true' &&
       uval="$OPTARG";;
    p) p_flag='true'
       pval="$OPTARG";;
    *) print_usage
       exit 1 ;;
  esac
done

echo 'Installing Sarus...'
echo "You need to have configured a .env file with required parameters. If you haven't done so, use the env.template file"

# checking docker version
currentver="$(docker --version)"
requiredver="Docker version 19.03.6"
 if [ "$(printf '%s\n' "$requiredver" "$currentver" | sort -V | head -n1)" = "$requiredver" ]; then
        echo "Greater than or equal to ${requiredver}"
 else
        echo "Your Docker version is less than ${requiredver}"
        exit 1
 fi

# checking docker-compose version
# TODO

echo 'Authenticating to the container registry...'
docker login registry.gitlab.com/sarus-tech -p $pval -u $uval

echo 'Pulling docker images...'
docker-compose pull

echo 'Launching Sarus'
docker-compose up -d
