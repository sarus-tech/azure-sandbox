psql -v ON_ERROR_STOP=1 --username postgres --dbname postgres <<-EOSQL
    CREATE USER private_learning_lab WITH ENCRYPTED PASSWORD '${POSTGRES_PRIVATE_LEARNING_LAB_PASSWORD}';
    CREATE USER dataowner_api WITH ENCRYPTED PASSWORD '${POSTGRES_DATAOWNER_API_PASSWORD}';
    CREATE DATABASE access_log;
EOSQL
# TODO fix that! this is horrible
psql -v ON_ERROR_STOP=1 --username postgres --dbname access_log <<-EOSQL
    CREATE TABLE access_log
    (
        id           serial not null
            constraint access_log_pkey
                primary key,
        time         timestamp,
        path         varchar(200),
        request_data bytea,
        status_code  integer,
        username     varchar(40),
        user_id      integer,
        organization_id integer
    );
    GRANT CONNECT ON DATABASE access_log TO private_learning_lab;
    GRANT INSERT, SELECT (id) ON TABLE access_log TO private_learning_lab;
    GRANT SELECT, UPDATE ON SEQUENCE access_log_id_seq TO private_learning_lab;
    GRANT CONNECT ON DATABASE access_log TO dataowner_api;
    GRANT SELECT ON TABLE access_log TO dataowner_api;
EOSQL
