#!/bin/sh

[ ! -z $SSL_DIR_PATH ] && CONF_FILE="nginx_ssl.conf" || CONF_FILE="nginx.conf"
envsubst '${NGINX_HOST}' < /nginx-conf/$CONF_FILE > /etc/nginx/conf.d/default.conf
exec nginx -g "daemon off;"

